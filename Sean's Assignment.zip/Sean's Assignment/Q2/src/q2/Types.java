package q2;

enum DogType {
	HOUND,
	GUNDOG,
	TERRIER,
	UTILITY,
	WORKING,
	PASTORAL,
	TOY
}

enum CatType {
	LION,
	TIGER,
	HOUSE_CAT,
	PUMA
}
